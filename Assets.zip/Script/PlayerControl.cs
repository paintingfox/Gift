using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class PlayerControl : MonoBehaviour
{
    // Start is called before the first frame update
    public Rigidbody2D rigid2D;
    void Start()
    {
        
    }

    // ���� ����
    public float jumpPower = 18;
    // ���� Ȯ��
    public bool onfloor = true;
    // �̵� �ӵ�
    public float moveSpeed = 10;

    // Update is called once per frame
    void Update(){
        bool left = Input.GetKey("a");
        bool right = Input.GetKey("d");
        bool jump = Input.GetKeyDown(KeyCode.Space);


        if (Hp <= 0)
        {
            Destroy(gameObject);
        }


        // ����
        if (jump == true && onfloor == true)
        {
            rigid2D.velocity = new Vector2(rigid2D.velocity.x, jumpPower);
            onfloor = false;
        }
        // �� �̵�
        else if (left == true)
        {
            rigid2D.AddForce(Vector2.left * moveSpeed);
            transform.eulerAngles = new Vector3(0, 180, 0);
        }
        // �� �̵�
        else if (right == true)
        {
            rigid2D.AddForce(Vector2.right * moveSpeed);
            transform.eulerAngles = new Vector3(0, 0, 0);
        }

        // �ӵ� ����
        if (rigid2D.velocity.x >= 10f) rigid2D.velocity = new Vector2(10f, rigid2D.velocity.y);
        else if (rigid2D.velocity.x <= -10f) rigid2D.velocity = new Vector2(-10f, rigid2D.velocity.y);
    }

    // �浹���϶�
    //void OnTriggerEnter2D(Collider2D collision)
    //{
    //    GetComponent<BoxCollider2D>().isTrigger = true;
    //}
    // �浹���� �ƴҶ�
    //void OnTriggerExit2D(Collider2D collision)
    //{
    //    GetComponent<BoxCollider2D>().isTrigger = false;
    //}

    private void OnCollisionEnter2D(Collision2D collision)
    {
        onfloor = true;
    }

    public int Hp = 3;

    public void TakeDamage(int damage)
    {
        Hp -= damage;
    }
}
